from quadprog import solve_qp
import numpy as np

def solve_quadprog(H, f, Aeq, beq):
    """
    Main entry point to do quadprog.
    Solves: 
        min 0.5*x'*H*x + f'*x subject to Aeq*x = beq
    Inputs:
        H: Laplacian matrix
        f: Fixed pin vector
        Aeq: Center-of-Gravity Constraint matrix
        beq: Center-of-Gravity Constraint vector
    Outputs:
        result_vector: Result of the quadratic programming (X location for cells given the constraints)
    """
    if len(beq) == 0:
        return solve_qp(H, f)
    result_vector = solve_qp(H, f, Aeq, beq, meq=len(beq))

    return result_vector