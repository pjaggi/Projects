import cvxpy as cp
import numpy as np
import scipy.sparse as sp

def solve_cvxpy(H, f, Aeq=None, beq=None):
    n = H.shape[0]
    x = cp.Variable(n)
    # Ensure H is symmetric
    H = 0.5 * (H + H.T)
    # Convert f to 1D numpy array
    f = np.array(f).flatten()
    # Validate beq if provided
    if beq is not None:
        beq = np.array(beq).flatten()
        if beq.size == 0:
            Aeq = None
            beq = None
    # Handle sparse inputs
    if sp.issparse(H):
        H_cvx = H
    else:
        H_cvx = sp.csc_matrix(H)
    constraints = []
    if Aeq is not None and beq is not None:
        if sp.issparse(Aeq):
            Aeq_cvx = Aeq
        else:
            Aeq_cvx = sp.csc_matrix(Aeq)
        constraints = [Aeq_cvx @ x == beq]
    objective = 0.5 * cp.quad_form(x, H_cvx) + f @ x
    prob = cp.Problem(cp.Minimize(objective), constraints)
    prob.solve(solver=cp.OSQP)
    if x.value is None:
        raise ValueError("Solver failed to find a solution.")
    return np.array(x.value).flatten()


