from cvxopt import matrix, spmatrix, solvers
import numpy as np
import scipy.sparse

def scipy_to_cvxopt_sparse(A):
    A = A.tocoo()
    return spmatrix(A.data.tolist(), A.row.tolist(), A.col.tolist(), size=A.shape)

def sparse_quadprog(H, f, Aeq=None, beq=None):
    """
    Solves: 
        min 0.5 * x^T H x + f^T x 
        subject to Aeq x = beq
    Inputs:
        H: Laplacian matrix (dense or scipy sparse)
        f: Fixed pin vector
        Aeq: Constraint matrix
        beq: Constraint vector
    Returns:
        Tuple: (result_vector,)
    """
    # Convert H to cvxopt matrix
    if scipy.sparse.issparse(H):
        P = scipy_to_cvxopt_sparse(H)
    else:
        P = matrix(H)
    q = matrix(f)
    # No equality constraints
    if Aeq is None or beq is None or len(beq) == 0:
        sol = solvers.qp(P, q)
    else:
        if scipy.sparse.issparse(Aeq):
            A = scipy_to_cvxopt_sparse(Aeq)
        else:
            A = matrix(Aeq)
        b = matrix(beq)
        sol = solvers.qp(P, q, None, None, A, b)
    return (np.array(sol['x']).flatten(),)