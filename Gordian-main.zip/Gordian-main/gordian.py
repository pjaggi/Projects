import networkx as nx
import numpy as np
import pandas as pd  # For displaying DataFrame
from typing import Dict, List
import argparse
from collections import namedtuple
from solve_quadprog import solve_quadprog
from sparse_quadprog import sparse_quadprog
from solve_cvxpy import solve_cvxpy
import time
import matplotlib.pyplot as plt
from cvxopt import matrix, spmatrix, solvers
import scipy.sparse as sp

# namedtuples (structs) to store the circuit information

CellProperties = namedtuple("CellProperties", ["width", "height", "power"]) # To store info in DIM file
IONode = namedtuple("IONode", ["x", "y"]) # To store info in IO file
NetLocation = namedtuple("NetLocation", ["x", "y"]) # To store the location of each net

# Global variables

NUM_NETS = 0 # Number of nets in the circuit
NUM_CELLS = 0 # Number of cells in the circuit
NUM_IO = 0 # Number of IO nodes in the circuit
CORE_HEIGHT = 0 # Height of the core
CORE_WIDTH = 0 # Width of the core
CORE_TO_IO_LR = 0.0 # <CORE-to-IO-left/right each> in dim file
CORE_TO_IO_TB = 0.0 # <CORE-to-IO-top/bottom each> in dim file
NUM_STAND_CELLS_PER_ROW = 0 # Number of standard cells per row in CORE

# Define I/O nodes (Dictionary to hold IO nodes [key] and their preferred boundary location in a tuple (x,y) [value])
IO_NODES: Dict[int, IONode] = {}

# Global variable to hold the netlist
# Each netlist is a list of nodes (ex: [1, 2, 3])
NETLIST: List[list] = []

# Global variable to hold the dimensions and power of each cell
# Each cell [key] is a cell_properties tuple [value]
CELL_PROPERTIES: Dict[int, CellProperties] = {}

# Gordian Matrices
ADJACENCY_MATRIX: np.ndarray
PIN_CONNECTION_MATRIX: np.ndarray
DEGREE_MATRIX: np.ndarray
LAPLACIAN_MATRIX: np.ndarray
FIXED_PIN_VECTOR_X: np.array
FIXED_PIN_VECTOR_Y: np.array

def parse_io_file(filename):
    """Parses an IO file and extracts the I/O nodes and their preferred boundary locations."""
    global NUM_IO
    with open(filename, 'r') as file:
        # Read the first line to find the number of IO nodes
        NUM_IO = int(file.readline().strip())
        # loop over all the ios and store their boundary locations in IO_NODES (nets start from 1 which is the first IO node)
        for i in range(1, NUM_IO + 1):
            line = file.readline().strip().split(sep=",")
            node = i

            io_node = IONode(x=int(line[0]), y=int(line[1]))
            IO_NODES[node] = io_node

def parse_hgr_file(filename):
    """Parses an HGR file and extracts the number of nets and cells along with the netlist."""
    global NUM_NETS, NUM_CELLS, NETLIST
    with open(filename,'r') as file:
        # Read the first line to find the number of nets and cells
        line = file.readline().strip().split(sep=" ")
        NUM_NETS = int(line[0])
        NUM_CELLS = int(line[1])

        for _ in range(NUM_NETS):
            line = file.readline().strip().split(sep=" ")

            # map each enrty in the line as an integer
            net = list(map(int, line))

            # add the net to the NETLIST
            NETLIST.append(net)

def parse_dim_file(filename):
    """Parses a DIM file and extracts the dimensions and power of each cell."""
    global CORE_HEIGHT, CORE_WIDTH, CORE_TO_IO_LR, CORE_TO_IO_TB, NUM_STAND_CELLS_PER_ROW, NUM_CELLS
    global CELL_PROPERTIES
    with open(filename, 'r') as file:
        first_line = file.readline().strip().split(sep=" ")
        CORE_WIDTH = int(first_line[0]) 
        CORE_HEIGHT = int(first_line[1])
        CORE_TO_IO_LR = float(first_line[2])
        CORE_TO_IO_TB = float(first_line[3])
        NUM_STAND_CELLS_PER_ROW = int(first_line[4])

        for cell in range(1, NUM_CELLS + 1):
            line = file.readline().strip().split(sep=",")

            cell_properties = CellProperties(width=float(line[0]), height=float(line[1]), power=float(line[2]))
            CELL_PROPERTIES[cell] = cell_properties

def parse_circuit_file(filename):
    """Parses a circuit netlist file and extracts nets as cliques while tracking net information."""
    G = nx.Graph()
    netlist = {}  # Dictionary to store net-to-nodes mapping

    with open(filename, 'r') as file:
        for line in file:
            parts = line.strip().split(':')
            if len(parts) < 2:
                continue  # Skip malformed lines
            net_name = parts[0].strip()  # Extract net name (e.g., Net1, Net2)
            nodes = parts[1].strip().split()  # Extract nodes in this net
            
            # Store in netlist dictionary
            netlist[net_name] = nodes  

            # Form a clique (fully connected subgraph)
            for i in range(len(nodes)):
                for j in range(i + 1, len(nodes)):
                    G.add_edge(nodes[i], nodes[j])  # Add edges

    return G, netlist  # Return both graph and netlist

def contains_io_node(net):
    "Checks if a net contains an I/O node"
    global IO_NODES
    for node in net:
        if node in IO_NODES:
            return True
    return False

def is_io_node(node):
    "Checks if a node is an I/O node"
    global IO_NODES
    return node in IO_NODES

def build_adjacency_matrix():
    "Builds the adjacency matrix for the circuit"
    global NUM_CELLS, NUM_IO, NUM_NETS, NETLIST, ADJACENCY_MATRIX
    # Initialize the adjacency matrix with zeros
    ADJACENCY_MATRIX = np.zeros((NUM_CELLS - NUM_IO, NUM_CELLS - NUM_IO))

    for net in NETLIST:
        edge_weight = 2 / len(net)

        for cell in net:
            if not is_io_node(cell):
                for other_cell in net:
                    if cell != other_cell and not is_io_node(other_cell):
                        # - 1 to account for 0-based indexing, - NUM_IO to exclude I/O nodes
                        ADJACENCY_MATRIX[cell - 1 - NUM_IO][other_cell - 1 - NUM_IO] += edge_weight

def build_pin_matrix():
    "Builds the pin connection matrix for the circuit"
    global NUM_CELLS, NUM_IO, NUM_NETS, NETLIST, PIN_CONNECTION_MATRIX
    # Initialize the pin connection matrix with zeros
    PIN_CONNECTION_MATRIX = np.zeros((NUM_CELLS - NUM_IO, NUM_IO))

    for net in NETLIST:
        if contains_io_node(net):
            edge_weight = 2 / len(net)

            for cell in net:
                if not is_io_node(cell):
                    for io_node in net:
                        if is_io_node(io_node):
                            # - 1 to account for 0-based indexing, - NUM_IO to exclude I/O nodes
                            PIN_CONNECTION_MATRIX[cell - 1 - NUM_IO][io_node - 1] += edge_weight

def compute_degree_matrix():
    """computes the Degree Matrix using the adjacency matrix and pin connection matrix."""
    global ADJACENCY_MATRIX, PIN_CONNECTION_MATRIX, DEGREE_MATRIX
    rows_sum = np.sum(ADJACENCY_MATRIX, axis=1) + np.sum(PIN_CONNECTION_MATRIX, axis=1)
    DEGREE_MATRIX = np.diag(rows_sum)

def build_laplacian_matrix():
    """Builds the Laplacian Matrix using the Degree Matrix and the Adjacency Matrix."""
    global DEGREE_MATRIX, ADJACENCY_MATRIX, LAPLACIAN_MATRIX
    LAPLACIAN_MATRIX = DEGREE_MATRIX - ADJACENCY_MATRIX

def build_fixed_pin_vector():
    """Builds the fixed pin vector for the X and Y direction."""
    global NUM_CELLS, NUM_IO, FIXED_PIN_VECTOR_X, FIXED_PIN_VECTOR_Y, IO_NODES, PIN_CONNECTION_MATRIX

    location_vector_x = np.array([IO_NODES[i].x for i in range(1, NUM_IO + 1)])
    location_vector_y = np.array([IO_NODES[i].y for i in range(1, NUM_IO + 1)])

    FIXED_PIN_VECTOR_X = np.dot(PIN_CONNECTION_MATRIX, location_vector_x)
    FIXED_PIN_VECTOR_Y = np.dot(PIN_CONNECTION_MATRIX, location_vector_y)

def initialize_partition_level_0(x, y, grid_width, grid_height):
    partitions = [[(i, xi, yi) for i, (xi, yi) in enumerate(zip(x, y))]]
    bounds = [(0, grid_width, 0, grid_height)]
    return partitions, bounds

def recursive_bipartition(partitions, bounds, level):
    new_partitions = []
    new_bounds = []

    for partition, (x_min, x_max, y_min, y_max) in zip(partitions, bounds):
        if len(partition) <= 1:
            new_partitions.append(partition)
            new_bounds.append((x_min, x_max, y_min, y_max))
            continue

        sorted_partition = sorted(partition, key=lambda t: t[1] if level % 2 == 0 else t[2])
        mid = len(sorted_partition) // 2
        part1, part2 = sorted_partition[:mid], sorted_partition[mid:]

        if level % 2 == 0:  # vertical
            cut_x = (x_min + x_max) / 2
            new_bounds += [(x_min, cut_x, y_min, y_max), (cut_x, x_max, y_min, y_max)]
        else:  # horizontal
            cut_y = (y_min + y_max) / 2
            new_bounds += [(x_min, x_max, y_min, cut_y), (x_min, x_max, cut_y, y_max)]

        new_partitions += [part1, part2]

    return new_partitions, new_bounds

def compute_partition_grid_info(partitions, bounds, grid_width, grid_height, total_nodes):
    grid_info = []

    for (x_min, x_max, y_min, y_max), partition in zip(bounds, partitions):
        if x_max - x_min == 0 or y_max - y_min == 0:
            continue

        node_ratio = len(partition) / total_nodes
        area = grid_width * grid_height * node_ratio
        aspect_ratio = (x_max - x_min) / (y_max - y_min)
        scaled_width = (area * aspect_ratio) ** 0.5
        scaled_height = area / scaled_width
        midpoint = ((x_min + x_max) / 2, (y_min + y_max) / 2)

        grid_info.append({
            "grid_size": [scaled_width, scaled_height],
            "midpoint": midpoint,
            "num_nodes": len(partition)
        })

    return grid_info

def partition_nodes(x, y, grid_width, grid_height, level, partitions, bounds):
    if level == 0:
        partitions, bounds = initialize_partition_level_0(x, y, grid_width, grid_height)

    partitions, bounds = recursive_bipartition(partitions, bounds, level)
    grid_info = compute_partition_grid_info(partitions, bounds, grid_width, grid_height, len(x))

    return partitions, grid_info, bounds

def build_cog_vectors(partitioned_nodes, grid_info):
    """
    Builds the COG vectors for X and Y coordinates for each partition based on the pre-calculated midpoints
    from the grid_info.
    
    Args:
        partitioned_nodes: A list of partitions where each partition is a list of nodes.
        grid_info: A list containing the grid information (including midpoints) for each partition.
    
    Returns:
        cog_vector_x: The COG vector for the x-coordinates of each partition.
        cog_vector_y: The COG vector for the y-coordinates of each partition.
    """
    cog_vector_x = []
    cog_vector_y = []

    # Loop through each partition to get the COG based on the pre-calculated midpoints
    for info in grid_info:
        cog_x, cog_y = info['midpoint']  # Extract the midpoint from grid_info

        #Append the COGs to the respective vectors
        cog_vector_x.append(cog_x)
        cog_vector_y.append(cog_y)

    return np.array(cog_vector_x), np.array(cog_vector_y)

def build_cog_matrix(x, y, partitions):
    """
    Builds the COG matrix that tracks which partition each node belongs to.

    Args:
        x (list): x coordinates of the nodes.
        y (list): y coordinates of the nodes.
        partitions (list of lists): The list of partitions, where each partition is a list of nodes (xi, yi).

    Returns:
        cog_matrix (numpy array): A matrix where each row corresponds to a partition and each column
                                   corresponds to a node. The values in the matrix represent the weight of
                                   the nodes in each partition.
    """
    num_nodes = len(x)
    num_partitions = len(partitions)
    
    cog_matrix = np.zeros((num_nodes, num_partitions))

    # Assign each node to its partition based on its original index
    for i, partition in enumerate(partitions):
        weight = 1.0 / len(partition)

        for index, xi, yi in partition:
            cog_matrix[index, i] = weight
            #cog_matrix[i, index] = weight

    return cog_matrix

def print_matrix(matrix, row_labels, col_labels, title):
    """Prints a formatted matrix with row and column labels."""
    print(f"\n{title}:\n")

    # Print header (column labels)
    print("    ", "  ".join(f"{col:>5}" for col in col_labels))

    # Print matrix with row labels
    for i, row in enumerate(matrix):
        formatted_row = "  ".join(f"{val:>5.2f}" for val in row)
        print(f"{row_labels[i]:>3}  {formatted_row}")

def print_vector(vector,  title):
    """Prints a vector."""
    # Create a formatted string for each element in the vector
    formatted_values = [f"{val:>5.2f}" for val in vector]
    
    # Join the formatted strings with a space separator
    formatted_string = ' '.join(formatted_values)
    
    # Print the title and the formatted string
    print(f"\n{title}:\n{formatted_string}")

def display_matrices():
    """Displays the adjacency matrix, pin connection matrix, degree matrix, and Laplacian matrix for testing."""
    global ADJACENCY_MATRIX, PIN_CONNECTION_MATRIX, DEGREE_MATRIX, LAPLACIAN_MATRIX, FIXED_PIN_VECTOR_X, FIXED_PIN_VECTOR_Y
    global NUM_IO, NUM_CELLS, NUM_NETS

    print(f"\nCircuit Information:\n\nNumber of Nets: {NUM_NETS}\nNumber of Cells: {NUM_CELLS}\nNumber of I/O Nodes: {NUM_IO}\n")

    non_io_labels = list(range(NUM_IO + 1, NUM_CELLS + 1))
    io_labels = list(range(1, NUM_IO + 1))

    # Display the matrices
    print_matrix(matrix=ADJACENCY_MATRIX, row_labels=non_io_labels, col_labels=non_io_labels, title="Adjacency Matrix")
    print_matrix(matrix=PIN_CONNECTION_MATRIX, row_labels=non_io_labels, col_labels=io_labels, title="Pin Connection Matrix")
    print_matrix(matrix=DEGREE_MATRIX, row_labels=non_io_labels, col_labels=non_io_labels, title="Degree Matrix")
    print_matrix(matrix=LAPLACIAN_MATRIX, row_labels=non_io_labels, col_labels=non_io_labels, title="Laplacian Matrix")

    # Display the fixed pin vectors
    print_vector(FIXED_PIN_VECTOR_X.T, "Fixed Pin Vector Tranpose (X)")
    print_vector(FIXED_PIN_VECTOR_Y.T, "Fixed Pin Vector Tranpose (Y)")

def check_overlap(x1, y1, w1, h1, x2, y2, w2, h2):
    """Check if two cells overlap."""
    # Check if the cells' bounding boxes overlap.
    return not (x1 + w1 <= x2 or x1 >= x2 + w2 or y1 + h1 <= y2 or y1 >= y2 + h2)

def assign_cells_to_initial_rows(x_initial, y_initial, core_height, row_height):
    num_rows = int(core_height // row_height)
    row_bins = [[] for _ in range(num_rows)]

    for i in range(len(x_initial)):
        width = CELL_PROPERTIES[i + 1].width
        height = CELL_PROPERTIES[i + 1].height

        row_index = int(round(y_initial[i] / row_height))
        row_index = max(0, min(num_rows - 1, row_index))
        y_snap = row_index * row_height
        x_snap = x_initial[i]

        row_bins[row_index].append((x_snap, y_snap, width, height, i))

    return row_bins, num_rows

def resolve_fragmented_overlaps(row_bins, num_rows, core_width, row_height, site_width):
    cell_layout = [None] * sum(len(row) for row in row_bins)
    for row_idx in range(num_rows):
        row = sorted(row_bins[row_idx], key=lambda c: c[0])
        cur_x = 0.0
        for x, y, w, h, idx in row:
            if x >= cur_x and x + w <= core_width:
                cell_layout[idx] = (x, y, w, h)
                cur_x = x + w
            else:
                placed = False
                for offset in range(1, num_rows):
                    for direction in [-1, 1]:
                        new_row = row_idx + direction * offset
                        if 0 <= new_row < num_rows:
                            y_new = new_row * row_height
                            scan_x = x
                            while scan_x + w <= core_width:
                                overlap = any(not (scan_x + w <= px or scan_x >= px + pw)
                                              for px, _, pw, _, _ in row_bins[new_row])
                                if not overlap:
                                    row_bins[new_row].append((scan_x, y_new, w, h, idx))
                                    cell_layout[idx] = (scan_x, y_new, w, h)
                                    placed = True
                                    break
                                scan_x += site_width
                        if placed:
                            break
                    if placed:
                        break
                if not placed:
                    x_fallback = min(cur_x, core_width - w)
                    cell_layout[idx] = (x_fallback, y, w, h)
                    cur_x = x_fallback + w
    return cell_layout

def greedy_detailed_placement_fragmented(x_initial, y_initial, core_width, core_height):
    row_height = CELL_PROPERTIES[1].height
    site_width = 1.0
    row_bins, num_rows = assign_cells_to_initial_rows(x_initial, y_initial, core_height, row_height)
    return resolve_fragmented_overlaps(row_bins, num_rows, core_width, row_height, site_width)

def snap_to_bounding_box(x_result, y_result, core_width, core_height, verbose=False):
    """
    Clamps node positions to stay within the core bounding box.
    Args:
        x_result (np.ndarray): Array of x-coordinates (1D).
        y_result (np.ndarray): Array of y-coordinates (1D).
        core_width (float): Width of the core.
        core_height (float): Height of the core.
        verbose (bool): Whether to print snapping info (default: False).
    Returns: Tuple of (x_snapped, y_snapped): Snapped x and y coordinate arrays.
    """
    x_original = x_result.copy()
    y_original = y_result.copy()

    x_snapped = np.clip(x_result, 0, core_width)
    y_snapped = np.clip(y_result, 0, core_height)

    if verbose:
        snapped_indices = np.where((x_result != x_snapped) | (y_result != y_snapped))[0]
        if len(snapped_indices) > 0:
            print(f"\n[Snapping] {len(snapped_indices)} node(s) snapped to core bounds.")
            for idx in snapped_indices:
                print(f"  Node {idx}: ({x_original[idx]:.2f}, {y_original[idx]:.2f}) -> ({x_snapped[idx]:.2f}, {y_snapped[idx]:.2f})")
    return x_snapped, y_snapped

def compute_hpwl(netlist, cell_positions, io_nodes, num_io):
    """ Computes total Half-Perimeter Wirelength (HPWL) including IO nodes.
    Args:
        netlist: List of nets, where each net is a list of node indices (1-based).
        cell_positions: List of (x, y, w, h) tuples for each standard cell (0-based, skipping IO).
        io_nodes: Dictionary of IO nodes {node_index: IONode(x, y)}.
        num_io: Total number of IO nodes.
    Returns: total_hpwl (float): Sum of HPWL over all nets.
    """
    total_hpwl = 0.0
    for net in netlist:
        xs = []
        ys = []
        for node_index in net:
            if node_index <= num_io:
                io = io_nodes.get(node_index) # IO node
                if io is not None:
                    xs.append(io.x)
                    ys.append(io.y)
            else: # Standard cell (1-based index → 0-based cell_positions index)
                cell_idx = node_index - num_io - 1 
                if 0 <= cell_idx < len(cell_positions):
                    x, y, w, h = cell_positions[cell_idx]
                    center_x = x + w / 2
                    center_y = y + h / 2
                    xs.append(center_x)
                    ys.append(center_y)
        if xs and ys:
            hpwl = (max(xs) - min(xs)) + (max(ys) - min(ys))
            total_hpwl += hpwl
    return total_hpwl

def visualize_placement(final_positions, core_width, core_height, netlist=None, io_nodes=None, num_io=0, wire_en = 1, level=0):
    """ Visualizes the final placement of cells with optional wire connections and IO boundary ring.
    Args:
        final_positions: A list of (x, y, w, h) tuples for each placed cell.
        core_width (float): Width of the core in microns.
        core_height (float): Height of the core in microns.
        netlist: (Optional) List of nets to draw wires.
        io_nodes: (Optional) Dictionary of IO nodes {node_index: IONode(x, y)}.
        num_io: (Optional) Number of IO nodes. """
    if not final_positions:
        print("No cells to display.")
        return
    row_height = final_positions[0][3]  # Assume uniform height
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.set_xlim(-10, core_width + 10)  # Add margin for IO ring
    ax.set_ylim(-10, core_height + 10)
    ax.set_aspect('equal')
    ax.axis('off')
    ax.add_patch(plt.Rectangle((0, 0), core_width, core_height, fill=False, edgecolor='black', linewidth=2)) # Core boundary  
    ax.add_patch(plt.Rectangle((-5, -5), core_width + 10, core_height + 10, fill=False, edgecolor='gray', linewidth=1.0, alpha=0.6)) # IO ring visualization around core
    y = 0 # Horizontal row grid
    while y <= core_height:
        ax.plot([0, core_width], [y, y], color='black', linewidth=0.3, alpha=0.5)
        y += row_height
    for x, y, w, h in final_positions: # Cells
        ax.add_patch(plt.Rectangle((x, y), w, h, fill=False, edgecolor='red', linewidth=0.7))
    if netlist and io_nodes and wire_en == 1:
        draw_wire_connections(ax, netlist, final_positions, io_nodes, num_io)
    ax.set_title("Detailed Cell Placement")
    plt.tight_layout()
    plt.savefig(f"placement_level_{level}{'_wires' if wire_en == 1 else ''}.png", dpi=300)
    plt.show()

def draw_wire_connections(ax, netlist, cell_positions, io_nodes, num_io):
    """
    Draws light gray lines between all nodes in each net.
    Args:
        ax: Matplotlib axis to draw on.
        netlist: List of nets, each net is a list of node indices (1-based).
        cell_positions: List of (x, y, w, h) tuples for standard cells.
        io_nodes: Dictionary of IO nodes {node_index: IONode(x, y)}.
        num_io: Number of IO nodes (node indices <= num_io are IO).
    """
    for net in netlist:
        points = []
        for node in net:
            if node <= num_io: # IO node
                io = io_nodes.get(node)
                if io:
                    points.append((io.x, io.y))
            else: # Standard cell
                cell_idx = node - num_io - 1
                if 0 <= cell_idx < len(cell_positions):
                    x, y, w, h = cell_positions[cell_idx]
                    center_x = x + w / 2
                    center_y = y + h / 2
                    points.append((center_x, center_y))
        # Draw all pairwise connections in the net
        for i in range(len(points)):
            for j in range(i + 1, len(points)):
                x1, y1 = points[i]
                x2, y2 = points[j]
                ax.plot([x1, x2], [y1, y2], color='blue', linewidth=0.5, alpha=0.1)

def place_io_on_ring(io_nodes, core_width, core_height, margin=5):
    """
    Projects IO nodes onto the outer IO ring while preserving original direction.
    Args:
        io_nodes (dict): IO nodes from .dim file with initial (x, y).
        core_width (float): Width of the core.
        core_height (float): Height of the core.
        margin (float): How far the IO ring extends from the core boundary.

    Returns:
        dict: Updated IO node positions projected onto the IO ring.
    """
    updated_io_nodes = {}
    center_x = core_width / 2
    center_y = core_height / 2
    for idx, node in io_nodes.items():
        dx = node.x - center_x
        dy = node.y - center_y

        if dx == 0 and dy == 0:
            dx, dy = 1e-5, 1e-5  # Avoid divide-by-zero at center
        # Scale to edge + margin
        scale_x = (core_width / 2 + margin) / abs(dx) if dx != 0 else float('inf')
        scale_y = (core_height / 2 + margin) / abs(dy) if dy != 0 else float('inf')
        scale = min(scale_x, scale_y)
        x_new = center_x + dx * scale
        y_new = center_y + dy * scale
        updated_io_nodes[idx] = IONode(x_new, y_new)
    return updated_io_nodes

def visualize_raw_cell_boxes(x, y, core_width, core_height, level=0, io_nodes=None, num_io=0):
    """ Visualize raw cell positions as boxes before detailed placement. Includes IO ring and legal row gridlines. 
    Args:
        x (list or array): x-coordinates of cell centers.
        y (list or array): y-coordinates of cell centers.
        core_width (float): Width of the core.
        core_height (float): Height of the core.
        level (int): Iteration level to label the figure or filename.
        io_nodes (dict): Optional IO node dictionary {index: IONode(x, y)}.
        num_io (int): Number of IO nodes. """
    cell_width = CELL_PROPERTIES[1].width
    cell_height = CELL_PROPERTIES[1].height
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.set_xlim(-10, core_width + 10)
    ax.set_ylim(-10, core_height + 10)
    ax.set_aspect('equal')
    ax.axis('off')
    # Draw core boundary
    ax.add_patch(plt.Rectangle((0, 0), core_width, core_height, fill=False, edgecolor='black', linewidth=2))
    if io_nodes: # Draw IO ring
        ax.add_patch(plt.Rectangle((-5, -5), core_width + 10, core_height + 10, fill=False, edgecolor='gray', linewidth=1.0, alpha=1))
    # Draw horizontal legal row lines
    y_line = 0
    while y_line <= core_height:
        ax.plot([0, core_width], [y_line, y_line], color='black', linewidth=0.3, alpha=0.3)
        y_line += cell_height
    for xi, yi in zip(x, y):
        ax.add_patch(plt.Rectangle((xi - cell_width / 2, yi - cell_height / 2), cell_width, cell_height, fill=False, edgecolor='red', linewidth=0.7))
    ax.set_title(f"Level {level}")
    plt.tight_layout()
    plt.savefig(f"placement_level_{level}.png", dpi=300)
    plt.show()

if __name__ == "__main__":
    # Start the timer
    start_time = time.time()

    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Gordian Placement Tool")
    
    # required argument for benchmark name
    parser.add_argument("-b", "--benchmark", type=str, help="Benchmark name", required=True)

    # Optional argument verbose
    parser.add_argument("-v", "--verbose", help="increase output verbosity", action="store_true")

    parser.add_argument("-s", "--solver", choices=["quadprog", "cvxopt", "cvxpy"], default="quadprog", help="QP solver: quadprog, cvxopt, or cvxpy (default: quadprog)")

    args = parser.parse_args()
    benchmark = args.benchmark
    verbose = args.verbose
    solver = args.solver

    benchmark_path = f"./benchmarks/{benchmark}"

    input_hgr = f"{benchmark_path}/{benchmark}.hgr"
    input_dim = f"{benchmark_path}/{benchmark}.dim"
    input_io = f"{benchmark_path}/{benchmark}.io"

    parse_io_file(input_io)  # Parse IO file and store into IO_NODES

    # Must parse HGR before dim since it contains the number of cells
    parse_hgr_file(input_hgr)  # Parse HGR file and store into NUM_NETS, NUM_CELLS, and NETLIST

    parse_dim_file(input_dim)  # Parse DIM file and store into CORE_HEIGHT, CORE_WIDTH, CORE_TO_IO_LR, CORE_TO_IO_TB, NUM_STAND_CELLS_PER_ROW, and CELL_PROPERTIES

    build_adjacency_matrix()  # Build adjacency matrix for the circuit

    build_pin_matrix() # Build pin connection matrix for the circuit

    compute_degree_matrix()  # Compute degree matrix using adjacency matrix and pin connection matrix

    build_laplacian_matrix()  # Build Laplacian matrix using degree matrix and adjacency matrix

    build_fixed_pin_vector()  # Build fixed pin vector for X and Y directions

    if verbose:
        display_matrices()  # Display the matrices for testing

    cog_matrix = np.array([])  # Center-of-Gravity Constraint matrix
    cog_vector_x = np.array([])  # Center-of-Gravity X Constraint vector
    cog_vector_y = np.array([])  # Center-of-Gravity Y Constraint vector

    quad_prog_timer_start = time.time()

    # L0 placement
    if args.solver == "cvxopt":
        x_result = sparse_quadprog(LAPLACIAN_MATRIX, FIXED_PIN_VECTOR_X.T, cog_matrix, cog_vector_x)
        y_result = sparse_quadprog(LAPLACIAN_MATRIX, FIXED_PIN_VECTOR_Y.T, cog_matrix, cog_vector_y)
    elif args.solver == "cvxpy":
        x_result = solve_cvxpy(LAPLACIAN_MATRIX, FIXED_PIN_VECTOR_X.T, cog_matrix, cog_vector_x)
        y_result = solve_cvxpy(LAPLACIAN_MATRIX, FIXED_PIN_VECTOR_Y.T, cog_matrix, cog_vector_y)
    else:
        x_result = solve_quadprog(LAPLACIAN_MATRIX, FIXED_PIN_VECTOR_X.T, cog_matrix, cog_vector_x)
        y_result = solve_quadprog(LAPLACIAN_MATRIX, FIXED_PIN_VECTOR_Y.T, cog_matrix, cog_vector_y)

    #IO_NODES = place_io_on_ring(IO_NODES, CORE_WIDTH, CORE_HEIGHT, margin=5)
    if args.solver == "cvxpy":
        visualize_raw_cell_boxes(x_result, y_result, CORE_WIDTH, CORE_HEIGHT, level=0, io_nodes=IO_NODES, num_io=NUM_IO)
    else:
        visualize_raw_cell_boxes(x_result[0], y_result[0], CORE_WIDTH, CORE_HEIGHT, level=0, io_nodes=IO_NODES, num_io=NUM_IO)
    quad_prog_timer_end = time.time()

    print(f"\nQuadprog time taken: {(quad_prog_timer_end - quad_prog_timer_start) * 1000:.2f} ms\n")

    if verbose:
        print_vector(x_result[0], "X Result for L0 Placement")
        print_vector(y_result[0], "Y Result for L0 Placement")

    # Now need to loop for X iterations or maybe until certain result is reached
    # Beginning of each loop I partion the cells and calculate the center of gravity constraints for each partition
    # Then I solve the quadprog problem for X and Y and repeat the process until the stop condition is met
    LAPLACIAN_MATRIX = sp.csr_matrix(LAPLACIAN_MATRIX)

    # Temporary variables for testing
    if args.solver == "cvxpy":
        num_nodes = len(x_result)
    else:
        num_nodes = len(x_result[0])
    level = 0 # CAN MAKE THIS INTO NUMBER OF LEVELS TO RUN THROUGH CONSISTENTLY
    max_level = int(np.ceil(np.log2(num_nodes))) - 1
    #max_level = 5
    partitioned_nodes = None
    bounds = None
    for i in range(max_level):
        #print(f"\nIteration {i + 1}:\n")
        # Partition the cells and calculate the center of gravity constraints for each partition
        print(CORE_HEIGHT)
        print(CORE_WIDTH)
        if args.solver == "cvxpy":
            print("Total number of nodes:", len(x_result))
        else:
            print("Total number of nodes:", len(x_result[0]))

        # Partition the grid and track partition coordinates
        if args.solver == "cvxpy":
            partitioned_nodes, grid_info, bounds = partition_nodes(x_result, y_result, CORE_WIDTH, CORE_HEIGHT, i, partitioned_nodes, bounds)
        else:
            partitioned_nodes, grid_info, bounds = partition_nodes(x_result[0], y_result[0], CORE_WIDTH, CORE_HEIGHT, i, partitioned_nodes, bounds)

        for j, info in enumerate(grid_info):
            print(f"Partition {j+1}:")
            print(f"  Grid Size: {info['grid_size']}")
            print(f"  Midpoint : {info['midpoint']}")
            print(f"  Num Nodes: {info['num_nodes']}")
            print()

        if args.solver == "cvxpy":
            cog_matrix = build_cog_matrix(x_result, y_result, partitioned_nodes)
        else:
            cog_matrix = build_cog_matrix(x_result[0], y_result[0], partitioned_nodes)
        print(cog_matrix)
        
        cog_vector_x, cog_vector_y = build_cog_vectors(partitioned_nodes, grid_info)
        print("COG Vector for X:", cog_vector_x)
        print("COG Vector for Y:", cog_vector_y)
        cog_matrix = sp.csr_matrix(cog_matrix)
        cog_matrix = cog_matrix.T  # Transpose to shape (num_constraints, num_variables)

        # Solve the quadprog problem for X and Y
        if args.solver == "cvxopt":
            x_result = sparse_quadprog(LAPLACIAN_MATRIX, FIXED_PIN_VECTOR_X.T, cog_matrix, cog_vector_x)
            y_result = sparse_quadprog(LAPLACIAN_MATRIX, FIXED_PIN_VECTOR_Y.T, cog_matrix, cog_vector_y)
        elif args.solver == "cvxpy":
            cog_vector_x = np.array(cog_vector_x).flatten()
            cog_vector_y = np.array(cog_vector_y).flatten()
            if cog_vector_x.size == 0:
                x_result = solve_cvxpy(LAPLACIAN_MATRIX, FIXED_PIN_VECTOR_X.T)
            else:
                x_result = solve_cvxpy(LAPLACIAN_MATRIX, FIXED_PIN_VECTOR_X.T, cog_matrix, cog_vector_x)
            if cog_vector_y.size == 0:
                y_result = solve_cvxpy(LAPLACIAN_MATRIX, FIXED_PIN_VECTOR_Y.T)
            else:
                y_result = solve_cvxpy(LAPLACIAN_MATRIX, FIXED_PIN_VECTOR_Y.T, cog_matrix, cog_vector_y)
        else:
            x_result = sparse_quadprog(LAPLACIAN_MATRIX, FIXED_PIN_VECTOR_X.T, cog_matrix, cog_vector_x)
            y_result = sparse_quadprog(LAPLACIAN_MATRIX, FIXED_PIN_VECTOR_Y.T, cog_matrix, cog_vector_y)

        IO_NODES = place_io_on_ring(IO_NODES, CORE_WIDTH, CORE_HEIGHT, margin=5)
        # cell_data used for prnting wire connections
        cell_data = []

        
        # print(cell_data)
        if args.solver == "cvxpy":
           for j in range(len(x_result)):
            cell_data.append((x_result[j], y_result[j], CELL_PROPERTIES[1].width, CELL_PROPERTIES[1].height))
           visualize_raw_cell_boxes(x_result, y_result, CORE_WIDTH, CORE_HEIGHT, level=i+1, io_nodes=IO_NODES, num_io=NUM_IO)
           visualize_placement(cell_data, CORE_WIDTH, CORE_HEIGHT, NETLIST, IO_NODES, NUM_IO, wire_en = 1, level=i+1)
        else:
           for j in range(len(x_result[0])):
            data = (x_result[0][j], y_result[0][j], CELL_PROPERTIES[1].width, CELL_PROPERTIES[1].height)
            cell_data.append(data)
        #    print(x_result)
           visualize_raw_cell_boxes(x_result[0], y_result[0], CORE_WIDTH, CORE_HEIGHT, level=i+1, io_nodes=IO_NODES, num_io=NUM_IO)
           visualize_placement(cell_data, CORE_WIDTH, CORE_HEIGHT, NETLIST, IO_NODES, NUM_IO, wire_en = 1, level=i+1)

    # Snap coordinates to valid region
    if args.solver == "cvxpy":
        x_result_snapped, y_result_snapped = snap_to_bounding_box(x_result, y_result, CORE_WIDTH, CORE_HEIGHT)
        x_result = x_result_snapped
        y_result = y_result_snapped
    else:
        x_result_snapped, y_result_snapped = snap_to_bounding_box(x_result[0], y_result[0], CORE_WIDTH, CORE_HEIGHT)
        x_result = (x_result_snapped,)  # Put back in tuple form
        y_result = (y_result_snapped,)
    IO_NODES = place_io_on_ring(IO_NODES, CORE_WIDTH, CORE_HEIGHT, margin=5)
    
    if args.solver == "cvxpy":
       visualize_raw_cell_boxes(x_result, y_result, CORE_WIDTH, CORE_HEIGHT, level=i+1, io_nodes=IO_NODES, num_io=NUM_IO)
    else:
       visualize_raw_cell_boxes(x_result[0], y_result[0], CORE_WIDTH, CORE_HEIGHT, level=i+1, io_nodes=IO_NODES, num_io=NUM_IO)
    
    # End the timer
    end_time = time.time()
    # Print the total time taken
    quad_prog = (end_time - start_time) * 1000
    #with open("timing_report.txt", "w") as f:
        #f.write(f"Quadprog time taken: {quad_prog:.2f} ms\n")


    start_time = time.time()
    # Perform Detailed Placement (greedy method) after global placement
    if args.solver == "cvxpy":
        detailed_cell_positions3 = greedy_detailed_placement_fragmented(x_result, y_result,
                                                                    CORE_WIDTH, CORE_HEIGHT)
    else:
        detailed_cell_positions3 = greedy_detailed_placement_fragmented(x_result[0], y_result[0], 
                                                                    CORE_WIDTH, CORE_HEIGHT)
    end_time = time.time()
    detailed_placement = (end_time - start_time) * 1000

    # Snap IO nodes to a ring 5 units outside the core
    IO_NODES = place_io_on_ring(IO_NODES, CORE_WIDTH, CORE_HEIGHT, margin=5)

    hpwl3 = compute_hpwl(NETLIST, detailed_cell_positions3, IO_NODES, NUM_IO)

    print(f"\nTotal HPWL after detailed placement (fragmented): {hpwl3:.2f}")
    print(f"\nTotal runtime: {quad_prog + detailed_placement:.2f} ms")

    print(num_nodes)
    print(max_level)
    # Visualize the final placement after detailed placement
    visualize_placement(detailed_cell_positions3, CORE_WIDTH, CORE_HEIGHT, NETLIST, IO_NODES, NUM_IO, wire_en = 0, level=i+1)
    visualize_placement(detailed_cell_positions3, CORE_WIDTH, CORE_HEIGHT, NETLIST, IO_NODES, NUM_IO, wire_en = 1, level=i+1)
    
    total_cell_area = sum(cell.width * cell.height for idx, cell in CELL_PROPERTIES.items() if idx > NUM_IO)
    print(f"Total cell area: {total_cell_area:.2f} square microns")

    if verbose:
        print_vector(x_result[0], f"X Result for L{i+1} Placement")
        print_vector(y_result[0], f"Y Result for L{i+1} Placement")